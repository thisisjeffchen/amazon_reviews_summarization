from data_utils import data_analysis
from config import DATA_PATH


if __name__ == "__main__":
    data_analysis(DATA_PATH, 'data/raw/reviews_Electronics.json.gz')

